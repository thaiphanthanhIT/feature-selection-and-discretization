# A Novel Dynamic Programming Method for Non-Parametric Data Discretization
## Usage
We build a package `binlib` to support the experiment process. 
## Reproducing experimental results
Run `test.py` for reproducing provided results, or running the algorithms on custom datasets. The command has the format:

`python test.py {dataset-name} {feature-name} {class-name} {metric: entropy/chi2/mi} {mode: min/max}`

For example:

```
python3 test.py FintechUser reward_rate y entropy min
```

`mode` option specifies the optimization direction (minimize or maximize the cost function). On default, `metric=entropy, mode=min`.

**NOTE:** The updated chi2 and mi are negative (i.e. `new_chi2` = `-old_chi2`), hence the corresponding mode should be `min`. We made this adjustment so that these metrics can be investigated using the alogrithm introducted by [Wang et al.]

The dataset used for experiements and corresponding results can be found in `experiments.zip`

