#/bin/sh

python test.py FintechUser age y entropy min
python test.py FintechUser age y chi2 min
python test.py FintechUser age y mi min

######### BEGIN OF BATCH 1 ##########

python test.py FintechUser reward_rate y entropy min
python test.py FintechUser reward_rate y chi2 min
python test.py FintechUser reward_rate y mi min

python test.py anneal-na width class entropy min
python test.py anneal-na width class chi2 min
python test.py anneal-na width class mi min

python test.py australian A14 class entropy min
python test.py australian A14 class chi2 min
python test.py australian A14 class mi min

python test.py cleve min_heart_rate class entropy min
python test.py cleve min_heart_rate class chi2 min
python test.py cleve min_heart_rate class mi min

python test.py CreditRisk int_rate y entropy min
python test.py CreditRisk int_rate y chi2 min
python test.py CreditRisk int_rate y mi min

python test.py CreditScore x003 y entropy min
python test.py CreditScore x003 y chi2 min
python test.py CreditScore x003 y mi min

python test.py vehicle SCALED_RADIUS_OF_GYRATION class entropy min
python test.py vehicle SCALED_RADIUS_OF_GYRATION class chi2 min
python test.py vehicle SCALED_RADIUS_OF_GYRATION class mi min

python test.py FinancialRisk interestRate y entropy min
python test.py FinancialRisk interestRate y chi2 min
python test.py FinancialRisk interestRate y mi min

python test.py hypothyroid FTI class entropy min
python test.py hypothyroid FTI class chi2 min
python test.py hypothyroid FTI class mi min

########## BEGIN OF BATCH 2 ##########
python test.py Pima Glucose class entropy min
python test.py Pima Glucose class chi2 min
python test.py Pima Glucose class mi min

python test.py spambase word_freq_your class entropy min
python test.py spambase word_freq_your class chi2 min
python test.py spambase word_freq_your class mi min

python test.py pendigits A5 class entropy min
python test.py pendigits A5 class chi2 min
python test.py pendigits A5 class mi min

python test.py yeast mcg class entropy min
python test.py yeast mcg class chi2 min
python test.py yeast mcg class mi min

python test.py pageblocks Length class entropy min
python test.py pageblocks Length class chi2 min
python test.py pageblocks Length class mi min

python test.py abalone Length class entropy min
python test.py abalone Length class chi2 min
python test.py abalone Length class mi min

python test.py satimage Sp36 class entropy min
python test.py satimage Sp36 class chi2 min
python test.py satimage Sp36 class mi min

python test.py segment Vedge-mean class entropy min
python test.py segment Vedge-mean class chi2 min
python test.py segment Vedge-mean class mi min

python test.py ecoli alm1 class entropy min
python test.py ecoli alm1 class chi2 min
python test.py ecoli alm1 class mi min

python test.py movement y22 class entropy min
python test.py movement y22 class chi2 min
python test.py movement y22 class mi min

python test.py musk f66 class entropy min
python test.py musk f66 class chi2 min
python test.py musk f66 class mi min

python test.py ILPD Sgot class entropy min
python test.py ILPD Sgot class chi2 min
python test.py ILPD Sgot class mi min

python test.py mfeat-fac A5 class entropy min
python test.py mfeat-fac A5 class chi2 min
python test.py mfeat-fac A5 class mi min

python test.py satellite A36 class entropy min
python test.py satellite A36 class chi2 min
python test.py satellite A36 class mi min

python test.py heart serum_cholestoral class entropy min
python test.py heart serum_cholestoral class chi2 min
python test.py heart serum_cholestoral class mi min