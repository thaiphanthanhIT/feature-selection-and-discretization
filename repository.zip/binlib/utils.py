import os
import sys
import math
import time

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import binlib
from binlib import utils, metrics

def visualize(viz, xtitle, ytitle, title, show = True, dir = None, legend = True):
    '''
    Visualize multiple plots on a same fig

    Input:
    -----
    viz {List of ([List], str)} : plots and their corresponding legends
    show : Whether to show the plot (Default: True)
    dir  : PATH for saving resulting plot

    Output:
    -----
    '''
    fig, axes = plt.subplots()
    for v in viz:
        axes.plot(np.arange(1, v[0].shape[0] + 1), v[0], label = v[1])
    if legend:
        axes.legend()
    axes.set_xlabel(xtitle)
    axes.set_ylabel(ytitle)
    axes.set_title(title)
    if dir is not None:
        plt.savefig(dir)
    if show:
        plt.show()

def cleanseNA(fea_vec):
    '''
    Cleanse a feature vector of a dataset by removing all missing instances.

    Input:
    -----
    fea_vec {numpy.ndarray} : Feature vector
    label {numpy.ndarray}   : Label vector

    Output:
    -----
    fea_vec {numpy.ndarray} : Cleansed feature
    '''
    avail_index = np.argwhere(~np.isnan(fea_vec)).flatten().tolist()
    return fea_vec[avail_index]

def makePrebins(df, feature, label, num_classes = 2):
    '''
    Pre-discretizing feature into pre-bins

    Input:
    -----
    df (pandas.DataFrame)   : List of instances to pre-discretize.
    feature                 : interested feature for evaluation.
    label                   : label column in dataset. MUST in the form of 0 ... (num_class-1) without NaN values
    num_class               : number of class

    Output:
    -----
    val (numpy.ndarray)    : List of distinct value regarding specified feature (0-based)
    freq (numpy.ndarray)   : Frequency of each aforementioned value (1-based)
    valdict (dictionary)   : val - freq mapping
    '''

    df[feature] = df[feature].astype(float)
    val = df[feature].unique()
    val = np.sort(val)
    val = cleanseNA(val)

    catcode = pd.Series(pd.Categorical(df[label], categories= df[label].unique())).cat.codes
    print(catcode)
    num_classes = max(catcode) + 1

    valdict = []
    for i in range(num_classes):
        valdict.append(dict.fromkeys(val, 0))

    for i in range(len(df)):
        if np.isnan(df[feature][i]) or catcode[i] == -1:
            continue
        valdict[catcode[i]][df[feature][i]] += 1

    freq = []
    for i in range(num_classes):
        freq.append([0] + list(valdict[i].values()))
    
    freq = np.array(freq)

    return val, freq, valdict

def equalSize(freq, n_bin, metric = 'entropy'):
    '''
    Equal size (frequency) binning over freq.
    '''
    n_val = freq.shape[1] - 1
    population = np.sum(freq)
    bin_freq = []
    score = 0

    ptr1 = 1
    ptr2 = 1
    curbin = 1

    while True:
        if (np.sum(freq[:, ptr1:(ptr2+1)]) * n_bin <= population or ptr2 == ptr1) and ptr2 < n_val:
            ptr2 += 1
        else:
            if curbin == n_bin:
                bin_freq.append(np.sum(freq[:, ptr1 : (n_val + 1)], axis= 1))
                score += metrics.getMetric(freq[:, ptr1 : (n_val + 1)], freq, metric)
                return bin_freq, score
            
            bin_freq.append(np.sum(freq[:, ptr1:ptr2], axis= 1))
            score += metrics.getMetric(freq[:, ptr1:ptr2], freq, metric)
            ptr1 = ptr2

            curbin += 1

def equalWidth(val, freq, n_bin, metric = 'entropy'):
    '''
    Equal width binning over freq. Only entropy are supported
    '''
    score = 0

    val_min = np.min(val)
    val_max = np.max(val)
    val_size = float((val_max - val_min) / n_bin)

    val_intervals = []
    cur_l = val_min
    cur_r = val_min + val_size

    for i in range(n_bin):
        val_intervals.append((cur_l, cur_r))
        cur_l = cur_r
        cur_r += val_size

    score = 0.0
    # print(val_intervals)

    for interval in val_intervals:
        cur_bin_idx = []
        for i in range(1, freq.shape[1]):
            if (val[i-1] < interval[1]) and (val[i-1] >= interval[0]):
                cur_bin_idx.append(i)
        score += metrics.getMetric(freq[:, cur_bin_idx], freq, metric)

    return score

def initMode(mode, val= 1e9):
    '''
    Initial value for corresponding mode ('min' or 'max').
    Default absolute value: 1e9
    '''
    if mode == 'min':
        return val
    else:
        return -val