import os
import sys
import math
import time

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import binlib
from binlib import utils, metrics

def Opt(val, cand, mode):
    '''
    Update 'val' using 'cand', regarding 'mode'

    Output:
    -----
    winner : 'val' or 'cand', depending on 'mode'
    update {boolean} : whether to update val by cand
    '''
    if mode == 'min':
        if val > cand:
            return cand, True
        return val, False
    
    if mode == 'max':
        if val < cand:
            return cand, True
        return val, False
    
def Round(u, v):
    '''
    Error-wise round function proposed in original IJCAI-97 paper
    '''
    if v >= 0:
        return math.floor(u)
    else:
        return math.ceil(u)
    # return round(u)
    
def getAlgo(name, val, freq, threshold, mode = 'min', metric = 'entropy', **kwargs):
    if name == 'scoreDP':
        return scoreDP(val, freq, threshold, mode, metric, kwargs['L'], kwargs['R'])
    if name == 'nbinDP':
        return nbinDP(val, freq, threshold, mode, metric, kwargs['granularity'])

def scoreDP(val, freq, threshold, mode = 'min', metric = 'entropy', L = 5, R = 15):
    '''
    Proposed score-wise Dynamic programming algorithm
    NOTE: For DP[v][l], v is 1-based and l is 1-based

    Input:
    -----
    freq {numpy.ndarray}    : Frequency vector (1-based)
    threshold               : Score threshold
    mode {'min' or 'max'}   : Configure to minimize or maximize the metric (Default: 'min')
    metric {'entropy', ...} : Chosen metric (Default: 'entropy')
    L                       : Maximum number of discretized bin (Default: 5) 
    R                       : Maximum number of discretized bin (Default: 15) 

    Output:
    -----
    dp_record {List}        : List of dp[n_val][l]; l \in [1, R]
    
    '''
    print("Start of scoreDP")
    n_val = freq.shape[1] - 1

    dp = np.zeros(shape = (n_val + 10, R + 10))
    trace = np.zeros(shape = (n_val + 10, R + 10)) - 1
    mx_score = metrics.getMetric(freq[:, 1:], freq, metric)
    
    dp_record = [mx_score] # Initialize dp_record with dp[n_val][1]
    
    # Initialize
    for v in range(1, n_val+1):
        dp[v, 1] = metrics.getMetric(freq[:, 1:v+1], freq, metric)
    
    # Score-wise DP
    for l in range(2, R+1):
        for v in range(l, n_val+1):
            dp[v, l] = utils.initMode(mode)

            for u in range(l-1, v):
                cand_dp = dp[u, l-1] + metrics.getMetric(freq[:, u+1:v+1], freq, metric)
                dp[v, l], update = Opt(dp[v, l], cand_dp, mode)
                
                if update:
                    dp[v, l] = cand_dp
                    trace[v, l] = u

        print(f'{metric}: {dp[n_val, l]:.3f}, layer: {l}, mode: {mode}')
        dp_record.append(dp[n_val, l])

    # Rules inference
    # cur_bin = int(n_val)
    # cur_l = opt_l

    # while cur_bin > 0:
    #     split_val.append(val[cur_bin])
    #     cur_bin = int(trace[cur_bin][cur_l])
    #     cur_l -= 1

    # utils.visualize([(dp_record, 'scoreDP')])
    return np.array(dp_record)

def nbinDP(val, freq, threshold, mode = 'min', metric = 'entropy', granularity = 15):
    '''
    Original Dynamic programming algorithm proposed in IJCAI-97
    NOTE: For I[x][i], x is 0-based and i is 1-based

    Input:
    -----
    freq {numpy.ndarray}    : Frequency vector
    threshold               : Score threshold
    mode {'min' or 'max'}   : Configure to minimize or maximize the metric (Default: 'min')
    metric {'entropy', ...} : Chosen metric (Default: 'entropy')
    granularity             : Number of candidate score to sample uniformly in [0, threshold], equivalent to gamma/epsilon

    Output:
    -----
    
    '''
    print(f"Start of nbinDP, granularity = {granularity}")
    n_val = freq.shape[1] - 1
    print(n_val)
    R = granularity
    epsi = float(threshold / R)
    print(threshold, epsi)

    I = np.ones(shape = (R + 10, n_val + 10)) * utils.initMode(mode, val = n_val + 1)
    M = np.ones(shape = (R + 10, n_val + 10)) * utils.initMode(mode, val = n_val + 1)
    E = np.zeros(shape = (n_val + 10))

    trace = {}
    mx_score = metrics.getMetric(freq[:, 1:], freq, metric)
    if mode == 'max':
        mx_score = -mx_score
    layer_record = np.ones(shape = (n_val + 10)) * (mx_score)
    layer_record_m = np.ones(shape = (n_val + 10)) * (mx_score)
    cur_state = (R + 1, 0)
    if epsi < 0:
        cur_state = (0, 0)

    I[0, 0] = 0
    if epsi > 0:
        for x in range(R+1):
            I[x, 0] = 0
            M[x, 0] = 0

    rr = range(R+1)
    # if epsi < 0:
    #     rr = reversed(range(R+1))

    for x in rr:
        E[0] = 0.0
        for i in range(1, n_val+1):
            I[x, i] = utils.initMode(mode, val = n_val + 1)

            for j in range(i):
                y = Round(metrics.getMetric(freq[:, j+1:i+1], freq, metric) / (epsi), E[j])
                xy = x - y
                # if epsi < 0:
                #     xy = y - x
                if xy < 0:
                    continue
                
                tmp = I[x, i]
                # I is always minimized
                I[x, i], update = Opt(I[x, i], I[xy, j]+1, 'min')
                if update:
                    trace[(x, i)] = (xy, j)
                    I[x, i] = I[xy, j] + 1 
                    M[x, i] = M[xy, j] + metrics.getMetric(freq[:, j+1:i+1], freq, metric)
                    E[i] = E[j] + float(y*epsi) - metrics.getMetric(freq[:, j+1:i+1], freq, metric)
                else:
                    I[x, i] = tmp

        print(f'{metric}: {x*epsi:.3f}, layer: {I[x, n_val]}, mode: {mode}')
        
        # 'max' adjustments done
        if I[x, n_val] <= n_val:
            cur_layer = int(I[x, n_val])
            if layer_record[cur_layer] >= float(x*epsi) and mode == 'min':
                layer_record[cur_layer] = float(x*epsi)
                layer_record_m[cur_layer] = M[x, n_val]

            if layer_record[cur_layer] <= float(x*epsi) and mode == 'max':
                layer_record[cur_layer] = float(x*epsi)
                layer_record_m[cur_layer] = M[x, n_val]

        else:
            if metric != 'entropy':
                break

        if epsi > 0 and I[x, n_val] <= 10 and x < cur_state[0]:
            cur_state = (x, n_val)
        if epsi < 0 and I[x, n_val] <= 10 and x > cur_state[0]:
            cur_state = (x, n_val)

    tmp_I = mx_score
    tmp_M = mx_score
    for i in range(1, n_val + 1):
        if layer_record[i] >= mx_score:
            layer_record[i] = tmp_I
            layer_record_m[i] = tmp_M
        else:
            tmp_I = layer_record[i]
            tmp_M = layer_record_m[i]

    # # Result inference
    auth_score = 0.0
    while True:
        if(cur_state[1] == 0):
            break
        pre_state = trace[cur_state]
        u = pre_state[1]
        v = cur_state[1]
        auth_score += metrics.getMetric(freq[:, u+1:v+1], freq, metric)
        print(cur_state, auth_score, metrics.getMetric(freq[:, u+1:v+1], freq, metric))
        cur_state = pre_state

    # for i in range(1, n_val+1):
    #     for x in range(R+1):
    #         print(f"I[{x}, {i}]: ", I[x, i])
    return layer_record[1:n_val+1], layer_record_m[1:n_val+1], auth_score

def equalSize(df, FEATURE, n_bin, freq, val, metric = 'entropy'):
    if n_bin == len(val):
        score = 0.0
        for i in range(len(val)):
            score += metrics.getMetric(freq[:, i+1], freq, metric)
        return score

    fea = df[FEATURE].dropna()
    fea_val = np.array(fea)
    val_list = list(val)
    eS_mapping = np.array(pd.qcut(fea, q = n_bin, labels= False, duplicates= 'drop'))
    score = 0.0

    for i in range(n_bin):
        idx = []
        for j in range(len(fea_val)):
            if eS_mapping[j] == i:
                idx.append(val_list.index(fea_val[j]) + 1)
        idx = list(set(idx))
        if len(idx) > 0:
            score += metrics.getMetric(freq[:, idx], freq, metric)

    return score

def equalWidth(df, FEATURE, n_bin, freq, val, metric = 'entropy'):
    fea = df[FEATURE].dropna()
    fea_val = np.array(fea)
    val_list = list(val)
    eW_mapping = np.array(pd.cut(fea, bins = n_bin, labels= False))
    score = 0.0

    for i in range(n_bin):
        idx = []
        for j in range(len(fea_val)):
            if eW_mapping[j] == i:
                idx.append(val_list.index(fea_val[j]) + 1)
        idx = list(set(idx))
        if len(idx) > 0:
            score += metrics.getMetric(freq[:, idx], freq, metric)

    return score