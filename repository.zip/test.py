import os
import sys
import math
import time
import csv

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import binlib
from binlib import utils, binalgo, metrics, dtree

def extract(score, real_score, score_name, rtime, metric):
    '''
    Extract experimental results of [score_name] method with a solution vector of [score]

    Input:
    -----
    score {numpy.ndarray}   : score[i] indicates the optimal impurity over the (i+1)-bin solution
    score_name {string}     : experiment name
    rtime {int}             : experiment runtime
    metric {string}         : metric name
    
    Output:
    -----
    dict {dictionary}       : returning dictionary for csv formatting
    '''
    resdict = {}
    resdict['runtime'] = rtime
    resdict['method'] = score_name
    resdict['opt_score'] = np.min(score[0:10]) # Maximum: 10 bins
    resdict['real_score'] = real_score
    # resdict['5-bin'] = score[4]
    # resdict['10-bin'] = score[9]
    # resdict['15-bin'] = score[14]
    resdict['metric'] = metric

    n = score.shape[0]
    resdict['stopping_point'] = 1
    for i in range(n-1, 0, -1):
        if score[i] != score[i-1]:
            resdict['stopping_point'] = i+1
            break

    return resdict

print("START")

DATASET = sys.argv[1]
FEATURE = sys.argv[2]
LABEL = sys.argv[3]
METRIC = sys.argv[4]
MODE = sys.argv[5]
PATH = os.path.join('./data', f'{DATASET}.csv')
ROOT = f"__{DATASET}-{FEATURE}__"

if not os.path.exists(ROOT):
    os.mkdir(ROOT)
if not os.path.exists(os.path.join(ROOT, METRIC)):
    os.mkdir(os.path.join(ROOT, METRIC))

df = pd.read_csv(PATH)
df.replace(r'\W', np.nan, regex=True, inplace= True)
df[FEATURE] = df[FEATURE].astype(float)
df.dropna(subset= [LABEL], inplace= True)
val, freq, _ = utils.makePrebins(df, FEATURE, LABEL)

ax = df[FEATURE].hist(bins=freq.shape[1], grid=False)
ax.set_xlabel(FEATURE)
ax.set_ylabel("Frequency")
ax.set_title(f"{DATASET} - {FEATURE}")
fig = ax.get_figure()
fig.savefig(os.path.join(ROOT, "hist.png"))

utils.visualize([(np.sum(freq, axis = 0), 'freq')], xtitle= 'pre-bin index', ytitle= 'frequency', title= f"{DATASET} - {FEATURE}", dir = os.path.join(ROOT, 'freq.png'))

max_impurity = metrics.getMetric(freq[:, 1:], freq, METRIC)
if METRIC != 'entropy':
    max_impurity = binalgo.equalSize(df, FEATURE, len(val), freq, val, metric = METRIC)
    
field_names = ['method', 'metric', 'runtime', 'opt_score', 'real_score', 'stopping_point']

full_vec = []
ear_vec = []
ear20_vec = []
del_vec = []
resdicts = []

start_time = time.time()
nbin15I, nbin15M, real_score = binalgo.nbinDP(val, freq, threshold = max_impurity, granularity = 15, mode = MODE, metric = METRIC)
end_time = time.time()
full_vec.append((nbin15I[:10], 'nbinDP-15'))
ear_vec.append((nbin15I[:50], 'nbinDP-15'))
ear20_vec.append((nbin15I[:20], 'nbinDP-15'))
resdicts.append(extract(nbin15I, real_score, 'nbinDP-15', end_time - start_time, METRIC))
np.savetxt(os.path.join(ROOT, METRIC, 'nbin15I.csv'), nbin15I, delimiter= ',')
np.savetxt(os.path.join(ROOT, METRIC, 'nbin15M.csv'), nbin15M, delimiter= ',')

# if METRIC == 'entropy':
#     start_time = time.time()
#     nbin20I, nbin20M = binalgo.nbinDP(val, freq, threshold = max_impurity, granularity = 20, mode = MODE, metric = METRIC)
#     end_time = time.time()
#     full_vec.append((nbin20I, 'nbinDP-20'))
#     ear_vec.append((nbin20I[:50], 'nbinDP-20'))
#     ear20_vec.append((nbin20I[:20], 'nbinDP-20'))
#     resdicts.append(extract(nbin20I, 'nbinDP-20', end_time - start_time, METRIC))
#     np.savetxt(os.path.join(ROOT, METRIC, 'nbin20I.csv'), nbin20I, delimiter= ',')
#     np.savetxt(os.path.join(ROOT, METRIC, 'nbin20M.csv'), nbin20M, delimiter= ',')

start_time = time.time()
nbin50I, nbin50M, real_score = binalgo.nbinDP(val, freq, threshold = max_impurity, granularity = 50, mode = MODE, metric = METRIC)
end_time = time.time()
full_vec.append((nbin50I[:10], 'nbinDP-50'))
ear_vec.append((nbin50I[:50], 'nbinDP-50'))
ear20_vec.append((nbin50I[:20], 'nbinDP-50'))
resdicts.append(extract(nbin50I, real_score, 'nbinDP-50', end_time - start_time, METRIC))
np.savetxt(os.path.join(ROOT, METRIC, 'nbin50I.csv'), nbin50I, delimiter= ',')
np.savetxt(os.path.join(ROOT, METRIC, 'nbin50M.csv'), nbin50M, delimiter= ',')

start_time = time.time()
nbin100I, nbin100M, real_score = binalgo.nbinDP(val, freq, threshold = max_impurity, granularity = 100, mode = MODE, metric = METRIC)
end_time = time.time()
full_vec.append((nbin100I[:10], 'nbinDP-100'))
ear_vec.append((nbin100I[:50], 'nbinDP-100'))
ear20_vec.append((nbin100I[:20], 'nbinDP-100'))
resdicts.append(extract(nbin100I, real_score, 'nbinDP-100', end_time - start_time, METRIC))
np.savetxt(os.path.join(ROOT, METRIC, 'nbin100I.csv'), nbin100I, delimiter= ',')
np.savetxt(os.path.join(ROOT, METRIC, 'nbin100M.csv'), nbin100M, delimiter= ',')

# start_time = time.time()
# nbin200I, nbin200M = binalgo.nbinDP(val, freq, threshold = max_impurity, granularity = 200)
# end_time = time.time()
# full_vec.append((nbin200I, 'nbinDP-200'))
# ear_vec.append((nbin200I[:50], 'nbinDP-200'))
# ear20_vec.append((nbin200I[:20], 'nbinDP-200'))
# resdicts.append(extract(nbin200I, 'nbinDP-200', end_time - start_time))
# np.savetxt(os.path.join(ROOT, 'nbin200I.csv'), nbin200I, delimiter= ',')
# np.savetxt(os.path.join(ROOT, 'nbin200M.csv'), nbin200M, delimiter= ',')

# start_time = time.time()
# nbin1000I, nbin1000M = binalgo.nbinDP(val, freq, threshold = max_impurity, granularity = 1000)
# end_time = time.time()
# full_vec.append((nbin1000I, 'nbinDP-1000'))
# ear_vec.append((nbin1000I[:50], 'nbinDP-1000'))
# ear20_vec.append((nbin1000I[:20], 'nbinDP-1000'))
# resdicts.append(extract(nbin1000I, 'nbinDP-1000', end_time - start_time))
# np.savetxt(os.path.join(ROOT, 'nbin1000I.csv'), nbin1000I, delimiter= ',')
# np.savetxt(os.path.join(ROOT, 'nbin1000M.csv'), nbin1000M, delimiter= ',')

start_time = time.time()
score = binalgo.scoreDP(val, freq, threshold = 0.0, R = 10, mode = MODE, metric = METRIC)
print(score.shape)
end_time = time.time()
full_vec.append((score, 'scoreDP'))
ear_vec.append((score[:50], 'scoreDP'))
ear20_vec.append((score[:20], 'scoreDP'))
resdicts.append(extract(score, min(score), 'scoreDP', end_time - start_time, METRIC))
np.savetxt(os.path.join(ROOT, METRIC, 'scoreDP.csv'), score, delimiter= ',')

if METRIC == 'entropy':
    del_vec.append((nbin15I[:10] - score, 'delta-15'))
    del_vec.append((nbin50I[:10] - score, 'delta-50'))
    del_vec.append((nbin100I[:10] - score, 'delta-100'))

equalS = []
start_time = time.time()
for i in range(1, 10 + 1):
    tmp_score = binalgo.equalSize(df, FEATURE, i, freq, val, metric = METRIC)
    equalS.append(tmp_score)
    print(f'EqualSize, n_bin = {i}, score = {tmp_score:2f}')
end_time = time.time()
equalS = np.array(equalS)

full_vec.append((equalS[:10], 'equalSize'))
ear_vec.append((equalS[:50], 'equalSize'))
ear20_vec.append((equalS[:20], 'equalSize'))
resdicts.append(extract(equalS, min(equalS[0:10]), 'equalSize', end_time - start_time, METRIC))
np.savetxt(os.path.join(ROOT, METRIC, 'equalSize.csv'), equalS, delimiter= ',')

equalW = []
start_time = time.time()
for i in range(1, 10 + 1):
    tmp_score = binalgo.equalWidth(df, FEATURE, i, freq, val, metric = METRIC)
    equalW.append(tmp_score)
    print(f'EqualWidth, n_bin = {i}, score = {tmp_score:2f}')
end_time = time.time()
equalW = np.array(equalW)

full_vec.append((equalW[:10], 'equalWidth'))
ear_vec.append((equalW[:50], 'equalWidth'))
ear20_vec.append((equalW[:20], 'equalWidth'))
resdicts.append(extract(equalW, min(equalW[0:10]), 'equalWidth', end_time - start_time, METRIC))
np.savetxt(os.path.join(ROOT, METRIC, 'equalWidth.csv'), equalW, delimiter= ',')

with open(os.path.join(ROOT, 'stats.csv'), 'a') as file:
    writer = csv.DictWriter(file, fieldnames= field_names)
    if METRIC == 'entropy':
        writer.writeheader()
    writer.writerows(resdicts)
    file.close()

utils.visualize(full_vec, 
                xtitle= 'No. of discretized bin', 
                ytitle= f'{METRIC}', 
                title = f"{DATASET} - {FEATURE}: Binning results", 
                dir = os.path.join(ROOT, METRIC, 'full.png'))

utils.visualize(del_vec, 
                xtitle= 'No. of discretized bin', 
                ytitle= 'Score differences', 
                title = f"{DATASET} - {FEATURE}: Score differences ", 
                dir = os.path.join(ROOT, METRIC, 'delta.png'))

# utils.visualize(ear_vec, 
#                 xtitle= 'No. of discretized bin', 
#                 ytitle= f'{METRIC}', 
#                 title = f"{DATASET} - {FEATURE}: Binning results",
#                 dir = os.path.join(ROOT, METRIC, '50-bin.png'),
#                 legend= False)

# utils.visualize(ear20_vec, 
#                 xtitle= 'No. of discretized bin', 
#                 ytitle= f'{METRIC}', 
#                 title = f"{DATASET} - {FEATURE}: Binning results",
#                 dir = os.path.join(ROOT, METRIC, '20-bin.png'),
#                 legend= False)